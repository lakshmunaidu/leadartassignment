# Book My Seat

A BookMyShow-inspired seat-booking UI built with the Web Platform™ using vanilla HTML, CSS and JS.

Zero-dependency — no frameworks/libraries used.

Play with the [app](https://sagirk.github.io/book-my-seat/src/index.html).

[MIT Licensed](./LICENSE).
